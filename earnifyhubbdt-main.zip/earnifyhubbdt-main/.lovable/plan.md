

# Earnify — Earning & Task Platform

## Overview
A mobile-responsive web app where users earn rewards through tasks, referrals, and Gmail selling. Features manual bKash/Nagad payments, admin approval workflows, and a built-in admin panel.

**Backend:** Supabase (Auth, Database, Edge Functions)

---

## 1. Authentication & Account Activation
- **Sign up / Login** with email and password via Supabase Auth
- All new accounts default to **"Inactive"** status
- **Activation Flow:** Users see a payment screen with admin-configured bKash/Nagad numbers, submit their Transaction ID and payment number
- Admin reviews and approves activation requests → account becomes **"Active"**
- Inactive users can only see the activation payment screen

## 2. User Dashboard
- Clean, modern dashboard showing:
  - Account balance
  - Account status (Active/Inactive badge)
  - Total referrals (direct + team)
  - Pro Task unlock status
  - Quick action buttons for tasks, withdraw, referrals

## 3. Basic Tasks
- List of daily tasks (ad views, clicks) available to all active users
- Each task shows reward amount and completion status
- Tasks reset daily; admin controls task content and reward amounts

## 4. Pro Tasks
- Premium task section locked behind a one-time fee (50-100 BDT)
- Same manual bKash/Nagad payment flow as activation
- Admin approves Pro unlock → user gains access to higher-reward tasks
- Admin can add/edit/remove Pro Tasks from the panel

## 5. Gmail Selling Section
- Dedicated section for submitting Gmail accounts
- Displays an **admin-provided password/format** so users know how to create accounts
- Users submit Gmail ID + password pairs
- Submissions go to admin for review and approval
- Admin sets the reward amount per accepted submission

## 6. Referral System
- Each user gets a unique referral code/link
- Referrers earn a fixed commission when their referred user **activates** their account
- Referral tree tracking: Direct referrals and total team (indirect) referrals

## 7. Monthly Salary System
- Milestone-based salary qualification:
  - **10 direct referrals** + **30 total team referrals** → qualifies for **500 BDT/month**
- A "Claim Salary" button appears once milestones are met
- Admin reviews and processes salary claims

## 8. Withdrawal System
- Users request withdrawals by entering bKash/Nagad number and amount
- Minimum withdrawal threshold
- Admin reviews and manually processes withdrawals
- Transaction history visible to users

## 9. Admin Panel (Role-based, same app)
- **Payment Settings:** Manage bKash/Nagad display numbers
- **Activation Requests:** Approve/reject account activations
- **Pro Task Management:** Approve pro task purchases, add/edit/delete pro tasks
- **Gmail Management:** Review submissions, update admin password for Gmail creation
- **Task Management:** Set reward amounts for basic, pro, and Gmail tasks
- **Salary Claims:** View and process monthly salary requests
- **Withdrawals:** Review and process withdrawal requests
- **User Management:** View all users, their balances, referral stats

## 10. UI/UX Design
- Modern, clean mobile-first responsive design
- Bottom navigation bar for mobile (Dashboard, Tasks, Referrals, Withdraw, Profile)
- Toast notifications for success/pending/error states
- Clear payment instructions with copy-to-clipboard for payment numbers
- Status badges and progress indicators throughout

