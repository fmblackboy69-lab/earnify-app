import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useSettings } from "@/hooks/useSettings";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { Wallet, Loader2 } from "lucide-react";

export default function WithdrawPage() {
  const { user, profile } = useAuth();
  const { data: settings } = useSettings();
  const queryClient = useQueryClient();
  const [method, setMethod] = useState<"bkash" | "nagad">("bkash");
  const [amount, setAmount] = useState("");
  const [accountNumber, setAccountNumber] = useState("");

  const minWithdrawal = parseFloat(settings?.min_withdrawal || "50");

  const { data: withdrawals = [] } = useQuery({
    queryKey: ["withdrawals", user?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("withdrawals")
        .select("*")
        .eq("user_id", user!.id)
        .order("created_at", { ascending: false });
      return data || [];
    },
    enabled: !!user,
  });

  const withdrawMutation = useMutation({
    mutationFn: async () => {
      const amt = parseFloat(amount);
      if (amt < minWithdrawal) throw new Error(`Minimum withdrawal is ৳${minWithdrawal}`);
      if (amt > (profile?.balance || 0)) throw new Error("Insufficient balance");
      const { error } = await supabase.from("withdrawals").insert({
        user_id: user!.id,
        amount: amt,
        method,
        account_number: accountNumber.trim(),
      });
      if (error) throw error;
    },
    onSuccess: () => {
      setAmount("");
      setAccountNumber("");
      queryClient.invalidateQueries({ queryKey: ["withdrawals"] });
      toast({ title: "Withdrawal requested!", description: "Pending admin approval." });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const statusColor = (s: string) => {
    if (s === "completed") return "bg-primary";
    if (s === "rejected") return "bg-destructive";
    if (s === "processing") return "bg-accent";
    return "bg-muted-foreground";
  };

  return (
    <div className="mx-auto max-w-lg p-4">
      <h1 className="mb-4 text-2xl font-bold">Withdraw</h1>

      <Card className="mb-4">
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Wallet className="h-5 w-5" /> Balance: ৳{profile?.balance?.toFixed(2) || "0.00"}</CardTitle>
          <CardDescription>Minimum withdrawal: ৳{minWithdrawal}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Button type="button" variant={method === "bkash" ? "default" : "outline"} className="flex-1" onClick={() => setMethod("bkash")}>bKash</Button>
            <Button type="button" variant={method === "nagad" ? "default" : "outline"} className="flex-1" onClick={() => setMethod("nagad")}>Nagad</Button>
          </div>
          <div className="space-y-2">
            <Label>Amount (BDT)</Label>
            <Input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder={`Min ৳${minWithdrawal}`} />
          </div>
          <div className="space-y-2">
            <Label>Your {method} Number</Label>
            <Input value={accountNumber} onChange={(e) => setAccountNumber(e.target.value)} placeholder="01XXXXXXXXX" />
          </div>
          <Button className="w-full" onClick={() => withdrawMutation.mutate()} disabled={withdrawMutation.isPending || !amount || !accountNumber}>
            {withdrawMutation.isPending && <Loader2 className="animate-spin" />} Request Withdrawal
          </Button>
        </CardContent>
      </Card>

      <h2 className="mb-2 text-sm font-semibold text-muted-foreground uppercase tracking-wide">History</h2>
      {withdrawals.length === 0 ? (
        <p className="text-center text-muted-foreground py-4">No withdrawal history.</p>
      ) : (
        <div className="space-y-2">
          {withdrawals.map((w) => (
            <Card key={w.id}>
              <CardContent className="flex items-center justify-between p-3">
                <div>
                  <p className="font-medium">৳{w.amount}</p>
                  <p className="text-xs text-muted-foreground">{w.method} • {w.account_number}</p>
                  <p className="text-xs text-muted-foreground">{new Date(w.created_at).toLocaleDateString()}</p>
                </div>
                <Badge className={statusColor(w.status)}>{w.status}</Badge>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
