import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import { LogOut, Shield } from "lucide-react";

export default function ProfilePage() {
  const { profile, isAdmin, signOut } = useAuth();
  const navigate = useNavigate();

  return (
    <div className="mx-auto max-w-lg p-4">
      <h1 className="mb-4 text-2xl font-bold">Profile</h1>

      <Card className="mb-4">
        <CardHeader>
          <CardTitle>{profile?.full_name || "User"}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Email</span>
            <span>{profile?.email}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Status</span>
            <Badge className={profile?.status === "active" ? "bg-primary" : "bg-destructive"}>{profile?.status}</Badge>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Balance</span>
            <span className="font-bold">৳{profile?.balance?.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Pro Tasks</span>
            <Badge variant={profile?.pro_unlocked ? "default" : "secondary"}>{profile?.pro_unlocked ? "Unlocked" : "Locked"}</Badge>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Referral Code</span>
            <code className="rounded bg-muted px-2 py-0.5 text-xs">{profile?.referral_code}</code>
          </div>
        </CardContent>
      </Card>

      {isAdmin && (
        <Button className="mb-4 w-full" variant="outline" onClick={() => navigate("/admin")}>
          <Shield className="mr-2 h-4 w-4" /> Admin Panel
        </Button>
      )}

      <Button variant="destructive" className="w-full" onClick={signOut}>
        <LogOut className="mr-2 h-4 w-4" /> Sign Out
      </Button>
    </div>
  );
}
