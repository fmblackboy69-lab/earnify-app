import { useAuth } from "@/contexts/AuthContext";
import { useSettings } from "@/hooks/useSettings";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { Copy, Users, Award, Loader2 } from "lucide-react";

export default function ReferralsPage() {
  const { user, profile } = useAuth();
  const { data: settings } = useSettings();
  const queryClient = useQueryClient();

  const { data: directReferrals = [] } = useQuery({
    queryKey: ["referral-list", user?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("profiles")
        .select("id, full_name, email, status, created_at")
        .eq("referred_by", user!.id);
      return data || [];
    },
    enabled: !!user,
  });

  // Count team referrals (indirect - referred by my directs)
  const { data: teamCount = 0 } = useQuery({
    queryKey: ["team-referrals", user?.id, directReferrals],
    queryFn: async () => {
      if (directReferrals.length === 0) return 0;
      const directIds = directReferrals.map((r) => r.id);
      const { count } = await supabase
        .from("profiles")
        .select("*", { count: "exact", head: true })
        .in("referred_by", directIds);
      return count || 0;
    },
    enabled: !!user && directReferrals.length > 0,
  });

  const totalTeam = directReferrals.length + teamCount;
  const salaryDirectReq = parseInt(settings?.salary_direct_referrals || "10");
  const salaryTeamReq = parseInt(settings?.salary_team_referrals || "30");
  const qualifiesForSalary = directReferrals.length >= salaryDirectReq && totalTeam >= salaryTeamReq;

  const claimMutation = useMutation({
    mutationFn: async () => {
      const now = new Date();
      const { error } = await supabase.from("salary_claims").insert({
        user_id: user!.id,
        month: now.getMonth() + 1,
        year: now.getFullYear(),
        amount: parseFloat(settings?.salary_amount || "500"),
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["salary-claims"] });
      toast({ title: "Salary claimed!", description: "Your claim is pending admin review." });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const referralLink = `${window.location.origin}/auth?ref=${profile?.referral_code || ""}`;

  return (
    <div className="mx-auto max-w-lg p-4">
      <h1 className="mb-4 text-2xl font-bold">Referrals</h1>

      {/* Referral Link */}
      <Card className="mb-4">
        <CardContent className="p-4">
          <p className="text-sm text-muted-foreground mb-2">Your Referral Code</p>
          <div className="flex items-center gap-2">
            <code className="flex-1 rounded bg-muted px-3 py-2 text-sm font-mono">{profile?.referral_code}</code>
            <Button variant="outline" size="icon" onClick={() => { navigator.clipboard.writeText(referralLink); toast({ title: "Link copied!" }); }}>
              <Copy className="h-4 w-4" />
            </Button>
          </div>
          <p className="mt-2 text-xs text-muted-foreground">Commission: ৳{settings?.referral_commission || "20"} per activation</p>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="mb-4 grid grid-cols-2 gap-3">
        <Card>
          <CardContent className="flex flex-col items-center p-4">
            <Users className="mb-1 h-5 w-5 text-primary" />
            <p className="text-2xl font-bold">{directReferrals.length}</p>
            <p className="text-xs text-muted-foreground">Direct</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex flex-col items-center p-4">
            <Users className="mb-1 h-5 w-5 text-blue-500" />
            <p className="text-2xl font-bold">{totalTeam}</p>
            <p className="text-xs text-muted-foreground">Total Team</p>
          </CardContent>
        </Card>
      </div>

      {/* Salary */}
      <Card className="mb-4">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg"><Award className="h-5 w-5" /> Monthly Salary</CardTitle>
          <CardDescription>
            {salaryDirectReq} direct + {salaryTeamReq} team referrals = ৳{settings?.salary_amount || "500"}/month
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-3 space-y-1 text-sm">
            <div className="flex justify-between">
              <span>Direct: {directReferrals.length}/{salaryDirectReq}</span>
              <span>{directReferrals.length >= salaryDirectReq ? "✅" : "❌"}</span>
            </div>
            <div className="flex justify-between">
              <span>Team: {totalTeam}/{salaryTeamReq}</span>
              <span>{totalTeam >= salaryTeamReq ? "✅" : "❌"}</span>
            </div>
          </div>
          {qualifiesForSalary && (
            <Button className="w-full" onClick={() => claimMutation.mutate()} disabled={claimMutation.isPending}>
              {claimMutation.isPending && <Loader2 className="animate-spin" />} Claim Salary
            </Button>
          )}
        </CardContent>
      </Card>

      {/* Referral List */}
      <h2 className="mb-2 text-sm font-semibold text-muted-foreground uppercase tracking-wide">Your Referrals</h2>
      {directReferrals.length === 0 ? (
        <p className="text-center text-muted-foreground py-4">No referrals yet. Share your code!</p>
      ) : (
        <div className="space-y-2">
          {directReferrals.map((ref) => (
            <Card key={ref.id}>
              <CardContent className="flex items-center justify-between p-3">
                <div>
                  <p className="text-sm font-medium">{ref.full_name || ref.email}</p>
                  <p className="text-xs text-muted-foreground">{ref.email}</p>
                </div>
                <Badge variant={ref.status === "active" ? "default" : "secondary"}>{ref.status}</Badge>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
