import { supabase } from "@/integrations/supabase/client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { Check, X } from "lucide-react";
import { useSettings } from "@/hooks/useSettings";

export function AdminGmail() {
  const queryClient = useQueryClient();
  const { data: settings } = useSettings();

  const { data: submissions = [] } = useQuery({
    queryKey: ["admin-gmail"],
    queryFn: async () => {
      const { data } = await supabase
        .from("gmail_submissions")
        .select("*, profiles:user_id(email, full_name)")
        .eq("status", "pending")
        .order("created_at", { ascending: true });
      return data || [];
    },
  });

  const approveMutation = useMutation({
    mutationFn: async ({ id }: { id: string }) => {
      const { data, error } = await supabase.rpc("approve_gmail", { p_submission_id: id });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-gmail"] });
      toast({ title: "Gmail approved!" });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const rejectMutation = useMutation({
    mutationFn: async (id: string) => {
      const { data, error } = await supabase.rpc("reject_gmail", { p_submission_id: id });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-gmail"] });
      toast({ title: "Rejected" });
    },
  });

  return (
    <div className="space-y-3">
      <h2 className="text-lg font-semibold">Pending Gmail Submissions ({submissions.length})</h2>
      {submissions.length === 0 && <p className="text-muted-foreground py-4 text-center">No pending submissions.</p>}
      {submissions.map((s: any) => (
        <Card key={s.id}>
          <CardContent className="p-4">
            <p className="font-medium">{s.profiles?.full_name || s.profiles?.email}</p>
            <div className="text-xs text-muted-foreground mt-1 space-y-0.5">
              <p>Gmail: {s.gmail_address}</p>
              <p>Password: {s.gmail_password}</p>
              <p>{new Date(s.created_at).toLocaleString()}</p>
            </div>
            <div className="flex gap-2 mt-3">
              <Button size="sm" className="flex-1" onClick={() => approveMutation.mutate({ id: s.id })}>
                <Check className="mr-1 h-4 w-4" /> Approve (৳{settings?.gmail_reward})
              </Button>
              <Button size="sm" variant="destructive" className="flex-1" onClick={() => rejectMutation.mutate(s.id)}>
                <X className="mr-1 h-4 w-4" /> Reject
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
