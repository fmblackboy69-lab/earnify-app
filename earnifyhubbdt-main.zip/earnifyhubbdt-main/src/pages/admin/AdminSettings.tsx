import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useSettings } from "@/hooks/useSettings";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";
import { Loader2, Save } from "lucide-react";

const settingsFields = [
  { key: "bkash_number", label: "bKash Number" },
  { key: "nagad_number", label: "Nagad Number" },
  { key: "activation_fee", label: "Activation Fee (BDT)" },
  { key: "pro_unlock_fee", label: "Pro Unlock Fee (BDT)" },
  { key: "basic_task_reward", label: "Basic Task Reward (BDT)" },
  { key: "pro_task_reward", label: "Pro Task Reward (BDT)" },
  { key: "gmail_reward", label: "Gmail Reward (BDT)" },
  { key: "referral_commission", label: "Referral Commission (BDT)" },
  { key: "salary_amount", label: "Monthly Salary (BDT)" },
  { key: "salary_direct_referrals", label: "Salary: Direct Referrals Required" },
  { key: "salary_team_referrals", label: "Salary: Team Referrals Required" },
  { key: "min_withdrawal", label: "Minimum Withdrawal (BDT)" },
  { key: "gmail_password", label: "Gmail Creation Password" },
];

export function AdminSettings() {
  const { data: settings } = useSettings();
  const queryClient = useQueryClient();
  const [values, setValues] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (settings) setValues(settings);
  }, [settings]);

  const handleSave = async () => {
    setSaving(true);
    try {
      for (const [key, value] of Object.entries(values)) {
        if (settings?.[key] !== value) {
          const { error } = await supabase.from("admin_settings").update({ value }).eq("key", key);
          if (error) throw error;
        }
      }
      queryClient.invalidateQueries({ queryKey: ["admin-settings"] });
      toast({ title: "Settings saved!" });
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Platform Settings</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {settingsFields.map((f) => (
          <div key={f.key} className="space-y-1">
            <Label className="text-xs">{f.label}</Label>
            <Input value={values[f.key] || ""} onChange={(e) => setValues({ ...values, [f.key]: e.target.value })} />
          </div>
        ))}
        <Button className="w-full" onClick={handleSave} disabled={saving}>
          {saving ? <Loader2 className="animate-spin" /> : <Save className="mr-1 h-4 w-4" />} Save Settings
        </Button>
      </CardContent>
    </Card>
  );
}
