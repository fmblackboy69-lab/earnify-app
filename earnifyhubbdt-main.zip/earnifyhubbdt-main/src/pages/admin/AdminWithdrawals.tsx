import { supabase } from "@/integrations/supabase/client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";
import { Check, X } from "lucide-react";

export function AdminWithdrawals() {
  const queryClient = useQueryClient();

  const { data: withdrawals = [] } = useQuery({
    queryKey: ["admin-withdrawals"],
    queryFn: async () => {
      const { data } = await supabase
        .from("withdrawals")
        .select("*, profiles:user_id(email, full_name, balance)")
        .in("status", ["pending", "processing"])
        .order("created_at", { ascending: true });
      return data || [];
    },
  });

  const approveMutation = useMutation({
    mutationFn: async ({ id }: { id: string }) => {
      const { data, error } = await supabase.rpc("approve_withdrawal", { p_withdrawal_id: id });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-withdrawals"] });
      toast({ title: "Withdrawal completed!" });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const rejectMutation = useMutation({
    mutationFn: async (id: string) => {
      const { data, error } = await supabase.rpc("reject_withdrawal", { p_withdrawal_id: id });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-withdrawals"] });
      toast({ title: "Rejected" });
    },
  });

  return (
    <div className="space-y-3">
      <h2 className="text-lg font-semibold">Pending Withdrawals ({withdrawals.length})</h2>
      {withdrawals.length === 0 && <p className="text-muted-foreground py-4 text-center">No pending withdrawals.</p>}
      {withdrawals.map((w: any) => (
        <Card key={w.id}>
          <CardContent className="p-4">
            <div className="flex justify-between mb-2">
              <p className="font-medium">{w.profiles?.full_name || w.profiles?.email}</p>
              <p className="font-bold">৳{w.amount}</p>
            </div>
            <div className="text-xs text-muted-foreground space-y-0.5 mb-3">
              <p>Method: {w.method} • {w.account_number}</p>
              <p>Balance: ৳{w.profiles?.balance}</p>
              <p>{new Date(w.created_at).toLocaleString()}</p>
            </div>
            <div className="flex gap-2">
              <Button size="sm" className="flex-1" onClick={() => approveMutation.mutate({ id: w.id })}>
                <Check className="mr-1 h-4 w-4" /> Complete
              </Button>
              <Button size="sm" variant="destructive" className="flex-1" onClick={() => rejectMutation.mutate(w.id)}>
                <X className="mr-1 h-4 w-4" /> Reject
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
