import { supabase } from "@/integrations/supabase/client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { Check, X, Image as ImageIcon } from "lucide-react";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";

export function AdminTaskApprovals() {
  const queryClient = useQueryClient();

  const { data: completions = [] } = useQuery({
    queryKey: ["admin-task-completions"],
    queryFn: async () => {
      const { data } = await supabase
        .from("task_completions")
        .select("*, basic_tasks(title, reward_amount), profiles(email, full_name)")
        .eq("status", "pending")
        .order("completed_at", { ascending: false });
      return data || [];
    },
  });

  const approveMutation = useMutation({
    mutationFn: async (id: string) => {
      const { data, error } = await supabase.rpc("approve_task_completion", { p_completion_id: id });
      if (error) throw error;
      const result = data as Record<string, unknown> | null;
      if (result?.error) throw new Error(String(result.error));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-task-completions"] });
      toast({ title: "Approved!" });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const rejectMutation = useMutation({
    mutationFn: async (id: string) => {
      const { data, error } = await supabase.rpc("reject_task_completion", { p_completion_id: id });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-task-completions"] });
      toast({ title: "Rejected" });
    },
  });

  return (
    <div className="space-y-3">
      <h2 className="text-lg font-semibold">Pending Task Proofs ({completions.length})</h2>
      {completions.length === 0 && <p className="text-center text-muted-foreground py-8">No pending approvals</p>}
      {completions.map((c: any) => (
        <Card key={c.id}>
          <CardContent className="p-3 space-y-2">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">{c.basic_tasks?.title}</p>
                <p className="text-xs text-muted-foreground">{c.profiles?.email || c.profiles?.full_name}</p>
                <Badge variant="secondary" className="mt-1">৳{c.reward_amount}</Badge>
              </div>
              <div className="flex gap-1">
                <Button size="icon" variant="ghost" className="text-primary" onClick={() => approveMutation.mutate(c.id)} disabled={approveMutation.isPending}>
                  <Check className="h-5 w-5" />
                </Button>
                <Button size="icon" variant="ghost" className="text-destructive" onClick={() => rejectMutation.mutate(c.id)} disabled={rejectMutation.isPending}>
                  <X className="h-5 w-5" />
                </Button>
              </div>
            </div>
            {c.proof_url && (
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm" className="w-full">
                    <ImageIcon className="h-4 w-4 mr-1" /> View Proof
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-lg">
                  <img src={c.proof_url} alt="Task proof" className="w-full rounded-lg" />
                </DialogContent>
              </Dialog>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
