import { supabase } from "@/integrations/supabase/client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";
import { Check, X } from "lucide-react";

export function AdminSalary() {
  const queryClient = useQueryClient();

  const { data: claims = [] } = useQuery({
    queryKey: ["admin-salary"],
    queryFn: async () => {
      const { data } = await supabase
        .from("salary_claims")
        .select("*, profiles:user_id(email, full_name, balance)")
        .eq("status", "pending")
        .order("created_at", { ascending: true });
      return data || [];
    },
  });

  const approveMutation = useMutation({
    mutationFn: async ({ id }: { id: string }) => {
      const { data, error } = await supabase.rpc("approve_salary", { p_claim_id: id });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-salary"] });
      toast({ title: "Salary approved!" });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const rejectMutation = useMutation({
    mutationFn: async (id: string) => {
      const { data, error } = await supabase.rpc("reject_salary", { p_claim_id: id });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-salary"] });
      toast({ title: "Rejected" });
    },
  });

  return (
    <div className="space-y-3">
      <h2 className="text-lg font-semibold">Pending Salary Claims ({claims.length})</h2>
      {claims.length === 0 && <p className="text-muted-foreground py-4 text-center">No pending claims.</p>}
      {claims.map((c: any) => (
        <Card key={c.id}>
          <CardContent className="p-4">
            <div className="flex justify-between mb-2">
              <p className="font-medium">{c.profiles?.full_name || c.profiles?.email}</p>
              <p className="font-bold">৳{c.amount}</p>
            </div>
            <p className="text-xs text-muted-foreground mb-3">
              {c.month}/{c.year} • {new Date(c.created_at).toLocaleString()}
            </p>
            <div className="flex gap-2">
              <Button size="sm" className="flex-1" onClick={() => approveMutation.mutate({ id: c.id })}>
                <Check className="mr-1 h-4 w-4" /> Approve
              </Button>
              <Button size="sm" variant="destructive" className="flex-1" onClick={() => rejectMutation.mutate(c.id)}>
                <X className="mr-1 h-4 w-4" /> Reject
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
