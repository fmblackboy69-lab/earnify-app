import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export function AdminUsers() {
  const { data: users = [] } = useQuery({
    queryKey: ["admin-users"],
    queryFn: async () => {
      const { data } = await supabase
        .from("profiles")
        .select("*")
        .order("created_at", { ascending: false });
      return data || [];
    },
  });

  return (
    <div className="space-y-3">
      <h2 className="text-lg font-semibold">All Users ({users.length})</h2>
      {users.map((u) => (
        <Card key={u.id}>
          <CardContent className="p-3">
            <div className="flex items-center justify-between mb-1">
              <p className="font-medium text-sm">{u.full_name || u.email}</p>
              <Badge className={u.status === "active" ? "bg-primary" : u.status === "banned" ? "bg-destructive" : "bg-muted-foreground"}>{u.status}</Badge>
            </div>
            <div className="text-xs text-muted-foreground space-y-0.5">
              <p>{u.email}</p>
              <div className="flex gap-3">
                <span>Balance: ৳{u.balance}</span>
                <span>Pro: {u.pro_unlocked ? "Yes" : "No"}</span>
                <span>Ref: {u.referral_code}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
