import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { AdminActivations } from "./AdminActivations";
import { AdminTasks } from "./AdminTasks";
import { AdminTaskApprovals } from "./AdminTaskApprovals";
import { AdminGmail } from "./AdminGmail";
import { AdminWithdrawals } from "./AdminWithdrawals";
import { AdminSalary } from "./AdminSalary";
import { AdminSettings } from "./AdminSettings";
import { AdminUsers } from "./AdminUsers";

export default function AdminPage() {
  const navigate = useNavigate();

  return (
    <div className="mx-auto max-w-2xl p-4">
      <div className="mb-4 flex items-center gap-2">
        <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-2xl font-bold">Admin Panel</h1>
      </div>

      <Tabs defaultValue="activations">
        <TabsList className="mb-4 flex-wrap h-auto gap-1">
          <TabsTrigger value="activations">Activations</TabsTrigger>
          <TabsTrigger value="tasks">Tasks</TabsTrigger>
          <TabsTrigger value="task-proofs">Proofs</TabsTrigger>
          <TabsTrigger value="gmail">Gmail</TabsTrigger>
          <TabsTrigger value="withdrawals">Withdrawals</TabsTrigger>
          <TabsTrigger value="salary">Salary</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="activations"><AdminActivations /></TabsContent>
        <TabsContent value="tasks"><AdminTasks /></TabsContent>
        <TabsContent value="task-proofs"><AdminTaskApprovals /></TabsContent>
        <TabsContent value="gmail"><AdminGmail /></TabsContent>
        <TabsContent value="withdrawals"><AdminWithdrawals /></TabsContent>
        <TabsContent value="salary"><AdminSalary /></TabsContent>
        <TabsContent value="users"><AdminUsers /></TabsContent>
        <TabsContent value="settings"><AdminSettings /></TabsContent>
      </Tabs>
    </div>
  );
}
