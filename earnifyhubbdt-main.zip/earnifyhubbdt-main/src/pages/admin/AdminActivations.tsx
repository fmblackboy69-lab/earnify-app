import { supabase } from "@/integrations/supabase/client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { Check, X } from "lucide-react";

export function AdminActivations() {
  const queryClient = useQueryClient();

  const { data: payments = [] } = useQuery({
    queryKey: ["admin-activations"],
    queryFn: async () => {
      const { data } = await supabase
        .from("payments")
        .select("*, profiles:user_id(email, full_name)")
        .eq("status", "pending")
        .order("created_at", { ascending: true });
      return data || [];
    },
  });

  const approveMutation = useMutation({
    mutationFn: async ({ paymentId }: { paymentId: string }) => {
      const { data, error } = await supabase.rpc("approve_payment", { p_payment_id: paymentId });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-activations"] });
      toast({ title: "Approved!" });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const rejectMutation = useMutation({
    mutationFn: async (paymentId: string) => {
      const { data, error } = await supabase.rpc("reject_payment", { p_payment_id: paymentId });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-activations"] });
      toast({ title: "Rejected" });
    },
  });

  return (
    <div className="space-y-3">
      <h2 className="text-lg font-semibold">Pending Payments ({payments.length})</h2>
      {payments.length === 0 && <p className="text-muted-foreground py-4 text-center">No pending payments.</p>}
      {payments.map((p: any) => (
        <Card key={p.id}>
          <CardContent className="p-4">
            <div className="flex items-start justify-between mb-2">
              <div>
                <p className="font-medium">{p.profiles?.full_name || p.profiles?.email}</p>
                <Badge variant="outline" className="mt-1">{p.payment_type}</Badge>
              </div>
              <p className="font-bold">৳{p.amount}</p>
            </div>
            <div className="text-xs text-muted-foreground space-y-0.5 mb-3">
              <p>Method: {p.method}</p>
              <p>TxID: {p.transaction_id}</p>
              <p>Number: {p.payment_number}</p>
              <p>{new Date(p.created_at).toLocaleString()}</p>
            </div>
            <div className="flex gap-2">
              <Button size="sm" className="flex-1" onClick={() => approveMutation.mutate({ paymentId: p.id })}>
                <Check className="mr-1 h-4 w-4" /> Approve
              </Button>
              <Button size="sm" variant="destructive" className="flex-1" onClick={() => rejectMutation.mutate(p.id)}>
                <X className="mr-1 h-4 w-4" /> Reject
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
