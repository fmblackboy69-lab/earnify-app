import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { toast } from "@/hooks/use-toast";
import { Plus, Trash2, Loader2 } from "lucide-react";

export function AdminTasks() {
  const queryClient = useQueryClient();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [reward, setReward] = useState("");
  const [link, setLink] = useState("");
  const [isPro, setIsPro] = useState(false);

  const { data: tasks = [] } = useQuery({
    queryKey: ["admin-tasks"],
    queryFn: async () => {
      const { data } = await supabase.from("basic_tasks").select("*").order("created_at", { ascending: false });
      return data || [];
    },
  });

  const addMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("basic_tasks").insert({
        title: title.trim(),
        description: description.trim() || null,
        reward_amount: parseFloat(reward),
        link: link.trim() || null,
        is_pro: isPro,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      setTitle(""); setDescription(""); setReward(""); setLink("");
      queryClient.invalidateQueries({ queryKey: ["admin-tasks"] });
      toast({ title: "Task added!" });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("basic_tasks").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-tasks"] });
      toast({ title: "Task deleted" });
    },
  });

  const toggleMutation = useMutation({
    mutationFn: async ({ id, active }: { id: string; active: boolean }) => {
      const { error } = await supabase.from("basic_tasks").update({ is_active: active }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["admin-tasks"] }),
  });

  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="p-4 space-y-3">
          <h3 className="font-semibold">Add New Task</h3>
          <div className="space-y-2">
            <Input placeholder="Task title" value={title} onChange={(e) => setTitle(e.target.value)} />
            <Input placeholder="Description (optional)" value={description} onChange={(e) => setDescription(e.target.value)} />
            <Input placeholder="Task Link (URL)" value={link} onChange={(e) => setLink(e.target.value)} />
            <Input placeholder="Reward (BDT)" type="number" value={reward} onChange={(e) => setReward(e.target.value)} />
            <div className="flex items-center gap-2">
              <Switch checked={isPro} onCheckedChange={setIsPro} />
              <Label>Pro Task</Label>
            </div>
          </div>
          <Button className="w-full" onClick={() => addMutation.mutate()} disabled={addMutation.isPending || !title || !reward}>
            {addMutation.isPending ? <Loader2 className="animate-spin" /> : <Plus className="mr-1 h-4 w-4" />} Add Task
          </Button>
        </CardContent>
      </Card>

      <h2 className="text-lg font-semibold">All Tasks ({tasks.length})</h2>
      {tasks.map((t) => (
        <Card key={t.id}>
          <CardContent className="flex items-center justify-between p-3">
            <div>
              <div className="flex items-center gap-2">
                <p className="font-medium">{t.title}</p>
                {t.is_pro && <Badge className="bg-accent text-xs">Pro</Badge>}
              </div>
              <p className="text-xs text-muted-foreground">৳{t.reward_amount}</p>
              {t.link && <p className="text-xs text-blue-500 truncate max-w-[200px]">{t.link}</p>}
            </div>
            <div className="flex items-center gap-2">
              <Switch checked={t.is_active} onCheckedChange={(v) => toggleMutation.mutate({ id: t.id, active: v })} />
              <Button variant="ghost" size="icon" onClick={() => deleteMutation.mutate(t.id)}>
                <Trash2 className="h-4 w-4 text-destructive" />
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
