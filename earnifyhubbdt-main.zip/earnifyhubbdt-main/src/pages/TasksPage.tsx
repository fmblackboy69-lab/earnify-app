import { useState, useRef } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useSettings } from "@/hooks/useSettings";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "@/hooks/use-toast";
import { CheckCircle, Lock, Loader2, Copy, Mail, ExternalLink, Upload, Clock } from "lucide-react";

function TaskCard({ task, status, onSubmitProof, isPending }: {
  task: any;
  status: "none" | "pending" | "approved" | "rejected";
  onSubmitProof: (task: any, file: File) => void;
  isPending: boolean;
}) {
  const fileRef = useRef<HTMLInputElement>(null);

  return (
    <Card>
      <CardContent className="p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <p className="font-medium">{task.title}</p>
            {task.description && <p className="text-xs text-muted-foreground">{task.description}</p>}
            <Badge variant={task.is_pro ? "default" : "secondary"} className={`mt-1 ${task.is_pro ? "bg-accent" : ""}`}>৳{task.reward_amount}</Badge>
          </div>
          {status === "approved" && <CheckCircle className="h-6 w-6 text-primary shrink-0" />}
          {status === "pending" && <Badge variant="outline" className="shrink-0"><Clock className="h-3 w-3 mr-1" />Pending</Badge>}
          {status === "rejected" && <Badge variant="destructive" className="shrink-0">Rejected</Badge>}
        </div>

        {task.link && (
          <a href={task.link} target="_blank" rel="noopener noreferrer">
            <Button variant="outline" size="sm" className="w-full">
              <ExternalLink className="h-4 w-4 mr-1" /> Open Task Link
            </Button>
          </a>
        )}

        {(status === "none" || status === "rejected") && (
          <>
            <input
              type="file"
              accept="image/*"
              ref={fileRef}
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) onSubmitProof(task, file);
              }}
            />
            <Button
              size="sm"
              className="w-full"
              onClick={() => fileRef.current?.click()}
              disabled={isPending}
            >
              {isPending ? <Loader2 className="animate-spin mr-1 h-4 w-4" /> : <Upload className="h-4 w-4 mr-1" />}
              Upload Proof & Submit
            </Button>
          </>
        )}
      </CardContent>
    </Card>
  );
}

export default function TasksPage() {
  const { user, profile, refreshProfile } = useAuth();
  const { data: settings } = useSettings();
  const queryClient = useQueryClient();
  const [gmailAddress, setGmailAddress] = useState("");
  const [gmailPassword, setGmailPassword] = useState("");
  const [proMethod, setProMethod] = useState<"bkash" | "nagad">("bkash");
  const [proTxId, setProTxId] = useState("");
  const [proPayNum, setProPayNum] = useState("");

  const { data: tasks = [] } = useQuery({
    queryKey: ["tasks"],
    queryFn: async () => {
      const { data } = await supabase.from("basic_tasks").select("*").eq("is_active", true);
      return data || [];
    },
  });

  const { data: completions = [] } = useQuery({
    queryKey: ["task-completions", user?.id],
    queryFn: async () => {
      const today = new Date().toISOString().split("T")[0];
      const { data } = await supabase
        .from("task_completions")
        .select("task_id, status")
        .eq("user_id", user!.id)
        .eq("completed_at", today);
      return data || [];
    },
    enabled: !!user,
  });

  const submitProofMutation = useMutation({
    mutationFn: async ({ task, file }: { task: any; file: File }) => {
      // Upload proof image
      const ext = file.name.split(".").pop();
      const path = `${user!.id}/${task.id}-${Date.now()}.${ext}`;
      const { error: uploadError } = await supabase.storage.from("task-proofs").upload(path, file);
      if (uploadError) throw uploadError;

      const { data: urlData } = supabase.storage.from("task-proofs").getPublicUrl(path);

      // Complete task (creates pending completion)
      const { data, error } = await supabase.rpc("complete_task", { p_task_id: task.id });
      if (error) throw error;
      const result = data as Record<string, unknown> | null;
      if (result?.error) throw new Error(String(result.error));

      // Update completion with proof URL
      await supabase
        .from("task_completions")
        .update({ proof_url: urlData.publicUrl })
        .eq("user_id", user!.id)
        .eq("task_id", task.id)
        .eq("completed_at", new Date().toISOString().split("T")[0]);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["task-completions"] });
      toast({ title: "Proof submitted!", description: "Waiting for admin approval." });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const gmailMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("gmail_submissions").insert({
        user_id: user!.id,
        gmail_address: gmailAddress.trim(),
        gmail_password: gmailPassword.trim(),
        reward_amount: parseFloat(settings?.gmail_reward || "10"),
      });
      if (error) throw error;
    },
    onSuccess: () => {
      setGmailAddress(""); setGmailPassword("");
      toast({ title: "Submitted!", description: "Your Gmail submission is pending review." });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const proUnlockMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("payments").insert({
        user_id: user!.id,
        payment_type: "pro_unlock" as const,
        method: proMethod,
        amount: parseFloat(settings?.pro_unlock_fee || "100"),
        transaction_id: proTxId.trim(),
        payment_number: proPayNum.trim(),
      });
      if (error) throw error;
    },
    onSuccess: () => {
      setProTxId(""); setProPayNum("");
      toast({ title: "Payment submitted!", description: "Your Pro Task unlock is pending admin approval." });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const getTaskStatus = (taskId: string): "none" | "pending" | "approved" | "rejected" => {
    const c = completions.find((c: any) => c.task_id === taskId);
    if (!c) return "none";
    return (c.status as "pending" | "approved" | "rejected");
  };

  const basicTasks = tasks.filter((t) => !t.is_pro);
  const proTasks = tasks.filter((t) => t.is_pro);
  const displayNumber = proMethod === "bkash" ? settings?.bkash_number : settings?.nagad_number;

  return (
    <div className="mx-auto max-w-lg p-4">
      <h1 className="mb-4 text-2xl font-bold">Tasks</h1>
      <Tabs defaultValue="basic">
        <TabsList className="w-full">
          <TabsTrigger value="basic" className="flex-1">Basic</TabsTrigger>
          <TabsTrigger value="pro" className="flex-1">Pro</TabsTrigger>
          <TabsTrigger value="gmail" className="flex-1">Gmail</TabsTrigger>
        </TabsList>

        <TabsContent value="basic" className="space-y-3 mt-4">
          {basicTasks.length === 0 && <p className="text-center text-muted-foreground py-8">No tasks available right now.</p>}
          {basicTasks.map((task) => (
            <TaskCard
              key={task.id}
              task={task}
              status={getTaskStatus(task.id)}
              onSubmitProof={(t, file) => submitProofMutation.mutate({ task: t, file })}
              isPending={submitProofMutation.isPending}
            />
          ))}
        </TabsContent>

        <TabsContent value="pro" className="space-y-3 mt-4">
          {!profile?.pro_unlocked ? (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><Lock className="h-5 w-5" /> Unlock Pro Tasks</CardTitle>
                <CardDescription>Pay ৳{settings?.pro_unlock_fee || "100"} to access higher-reward tasks</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Button type="button" variant={proMethod === "bkash" ? "default" : "outline"} className="flex-1" onClick={() => setProMethod("bkash")}>bKash</Button>
                  <Button type="button" variant={proMethod === "nagad" ? "default" : "outline"} className="flex-1" onClick={() => setProMethod("nagad")}>Nagad</Button>
                </div>
                <div className="flex items-center justify-between rounded-lg border bg-muted p-3">
                  <div>
                    <p className="text-xs text-muted-foreground">Send to:</p>
                    <p className="font-bold">{displayNumber}</p>
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => { navigator.clipboard.writeText(displayNumber || ""); toast({ title: "Copied!" }); }}>
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
                <div className="space-y-2">
                  <Label>Transaction ID</Label>
                  <Input value={proTxId} onChange={(e) => setProTxId(e.target.value)} placeholder="Enter transaction ID" />
                </div>
                <div className="space-y-2">
                  <Label>Your {proMethod} Number</Label>
                  <Input value={proPayNum} onChange={(e) => setProPayNum(e.target.value)} placeholder="01XXXXXXXXX" />
                </div>
                <Button className="w-full" onClick={() => proUnlockMutation.mutate()} disabled={proUnlockMutation.isPending || !proTxId || !proPayNum}>
                  {proUnlockMutation.isPending && <Loader2 className="animate-spin" />} Submit Payment
                </Button>
              </CardContent>
            </Card>
          ) : (
            <>
              {proTasks.length === 0 && <p className="text-center text-muted-foreground py-8">No pro tasks available.</p>}
              {proTasks.map((task) => (
                <TaskCard
                  key={task.id}
                  task={task}
                  status={getTaskStatus(task.id)}
                  onSubmitProof={(t, file) => submitProofMutation.mutate({ task: t, file })}
                  isPending={submitProofMutation.isPending}
                />
              ))}
            </>
          )}
        </TabsContent>

        <TabsContent value="gmail" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Mail className="h-5 w-5" /> Sell Gmail</CardTitle>
              <CardDescription>Submit Gmail accounts for ৳{settings?.gmail_reward || "10"} each</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-lg border bg-muted p-3">
                <p className="text-xs text-muted-foreground mb-1">Use this password when creating:</p>
                <div className="flex items-center justify-between">
                  <p className="font-mono font-bold">{settings?.gmail_password || "Loading..."}</p>
                  <Button variant="ghost" size="icon" onClick={() => { navigator.clipboard.writeText(settings?.gmail_password || ""); toast({ title: "Copied!" }); }}>
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Gmail Address</Label>
                <Input value={gmailAddress} onChange={(e) => setGmailAddress(e.target.value)} placeholder="example@gmail.com" type="email" />
              </div>
              <div className="space-y-2">
                <Label>Gmail Password</Label>
                <Input value={gmailPassword} onChange={(e) => setGmailPassword(e.target.value)} placeholder="Password used" />
              </div>
              <Button className="w-full" onClick={() => gmailMutation.mutate()} disabled={gmailMutation.isPending || !gmailAddress || !gmailPassword}>
                {gmailMutation.isPending && <Loader2 className="animate-spin" />} Submit Gmail
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
