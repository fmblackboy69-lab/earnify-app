import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useSettings } from "@/hooks/useSettings";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { Copy, Loader2, LogOut, Clock } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

export default function ActivationPage() {
  const { user, signOut } = useAuth();
  const { data: settings } = useSettings();
  const [method, setMethod] = useState<"bkash" | "nagad">("bkash");
  const [transactionId, setTransactionId] = useState("");
  const [paymentNumber, setPaymentNumber] = useState("");
  const [loading, setLoading] = useState(false);

  const { data: pendingPayment } = useQuery({
    queryKey: ["pending-activation", user?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("payments")
        .select("*")
        .eq("user_id", user!.id)
        .eq("payment_type", "activation")
        .eq("status", "pending")
        .maybeSingle();
      return data;
    },
    enabled: !!user,
  });

  const copyNumber = (num: string) => {
    navigator.clipboard.writeText(num);
    toast({ title: "Copied!", description: "Number copied to clipboard" });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !settings) return;
    setLoading(true);
    try {
      const { error } = await supabase.from("payments").insert({
        user_id: user.id,
        payment_type: "activation" as const,
        method,
        amount: parseFloat(settings.activation_fee || "30"),
        transaction_id: transactionId.trim(),
        payment_number: paymentNumber.trim(),
      });
      if (error) throw error;
      toast({ title: "Payment submitted!", description: "Your activation request is pending admin approval." });
      setTransactionId("");
      setPaymentNumber("");
    } catch (error: any) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  if (pendingPayment) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="mx-auto mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-accent/20">
              <Clock className="h-6 w-6 text-accent" />
            </div>
            <CardTitle>Activation Pending</CardTitle>
            <CardDescription>Your activation payment is under review. Please wait for admin approval.</CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <Badge variant="outline" className="text-accent border-accent">Pending Review</Badge>
            <Button variant="ghost" className="mt-6 w-full" onClick={signOut}>
              <LogOut className="mr-2 h-4 w-4" /> Sign Out
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const displayNumber = method === "bkash" ? settings?.bkash_number : settings?.nagad_number;

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-primary">Activate Your Account</CardTitle>
          <CardDescription>
            Pay <span className="font-bold text-foreground">৳{settings?.activation_fee || "30"}</span> to activate
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-6 space-y-3">
            <div className="flex gap-2">
              <Button
                type="button"
                variant={method === "bkash" ? "default" : "outline"}
                className="flex-1"
                onClick={() => setMethod("bkash")}
              >
                bKash
              </Button>
              <Button
                type="button"
                variant={method === "nagad" ? "default" : "outline"}
                className="flex-1"
                onClick={() => setMethod("nagad")}
              >
                Nagad
              </Button>
            </div>
            <div className="flex items-center justify-between rounded-lg border bg-muted p-3">
              <div>
                <p className="text-xs text-muted-foreground">Send to this {method} number:</p>
                <p className="text-lg font-bold">{displayNumber || "Loading..."}</p>
              </div>
              <Button variant="ghost" size="icon" onClick={() => copyNumber(displayNumber || "")}>
                <Copy className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="txId">Transaction ID</Label>
              <Input id="txId" value={transactionId} onChange={(e) => setTransactionId(e.target.value)} required placeholder="Enter your transaction ID" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="payNum">Your {method} Number</Label>
              <Input id="payNum" value={paymentNumber} onChange={(e) => setPaymentNumber(e.target.value)} required placeholder="01XXXXXXXXX" />
            </div>
            <Button type="submit" className="w-full" disabled={loading}>
              {loading && <Loader2 className="animate-spin" />}
              Submit Payment
            </Button>
          </form>
          <Button variant="ghost" className="mt-4 w-full" onClick={signOut}>
            <LogOut className="mr-2 h-4 w-4" /> Sign Out
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
