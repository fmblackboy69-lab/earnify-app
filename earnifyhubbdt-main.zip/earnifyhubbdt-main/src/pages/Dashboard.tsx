import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { Wallet, Users, ListChecks, Star, TrendingUp } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export default function Dashboard() {
  const { profile, user } = useAuth();
  const navigate = useNavigate();

  const { data: directReferrals = 0 } = useQuery({
    queryKey: ["direct-referrals", user?.id],
    queryFn: async () => {
      const { count } = await supabase
        .from("profiles")
        .select("*", { count: "exact", head: true })
        .eq("referred_by", user!.id);
      return count || 0;
    },
    enabled: !!user,
  });

  const stats = [
    { label: "Balance", value: `৳${profile?.balance?.toFixed(2) || "0.00"}`, icon: Wallet, color: "text-primary" },
    { label: "Direct Referrals", value: directReferrals, icon: Users, color: "text-blue-500" },
    { label: "Pro Tasks", value: profile?.pro_unlocked ? "Unlocked" : "Locked", icon: Star, color: "text-accent" },
  ];

  return (
    <div className="mx-auto max-w-lg p-4">
      {/* Header */}
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Earnify</h1>
          <p className="text-sm text-muted-foreground">Welcome, {profile?.full_name || "User"}</p>
        </div>
        <Badge className={profile?.status === "active" ? "bg-primary" : "bg-destructive"}>
          {profile?.status || "inactive"}
        </Badge>
      </div>

      {/* Stats Grid */}
      <div className="mb-6 grid grid-cols-3 gap-3">
        {stats.map((stat) => (
          <Card key={stat.label}>
            <CardContent className="flex flex-col items-center p-4 text-center">
              <stat.icon className={`mb-1 h-5 w-5 ${stat.color}`} />
              <p className="text-lg font-bold">{stat.value}</p>
              <p className="text-[11px] text-muted-foreground">{stat.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Quick Actions */}
      <h2 className="mb-3 text-sm font-semibold text-muted-foreground uppercase tracking-wide">Quick Actions</h2>
      <div className="grid grid-cols-2 gap-3">
        <Button variant="outline" className="h-auto flex-col gap-2 py-4" onClick={() => navigate("/tasks")}>
          <ListChecks className="h-6 w-6 text-primary" />
          <span>Do Tasks</span>
        </Button>
        <Button variant="outline" className="h-auto flex-col gap-2 py-4" onClick={() => navigate("/withdraw")}>
          <Wallet className="h-6 w-6 text-primary" />
          <span>Withdraw</span>
        </Button>
        <Button variant="outline" className="h-auto flex-col gap-2 py-4" onClick={() => navigate("/referrals")}>
          <Users className="h-6 w-6 text-primary" />
          <span>Referrals</span>
        </Button>
        <Button variant="outline" className="h-auto flex-col gap-2 py-4" onClick={() => navigate("/tasks?tab=gmail")}>
          <TrendingUp className="h-6 w-6 text-primary" />
          <span>Sell Gmail</span>
        </Button>
      </div>
    </div>
  );
}
