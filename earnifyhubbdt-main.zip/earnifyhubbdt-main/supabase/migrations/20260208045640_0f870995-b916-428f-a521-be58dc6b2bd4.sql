
-- Create app_role enum
CREATE TYPE public.app_role AS ENUM ('admin', 'user');

-- Create account_status enum
CREATE TYPE public.account_status AS ENUM ('inactive', 'active', 'banned');

-- Create payment_status enum
CREATE TYPE public.payment_status AS ENUM ('pending', 'approved', 'rejected');

-- Create payment_type enum
CREATE TYPE public.payment_type AS ENUM ('activation', 'pro_unlock');

-- Create payment_method enum
CREATE TYPE public.payment_method AS ENUM ('bkash', 'nagad');

-- Create withdrawal_status enum
CREATE TYPE public.withdrawal_status AS ENUM ('pending', 'processing', 'completed', 'rejected');

-- Create gmail_status enum
CREATE TYPE public.gmail_status AS ENUM ('pending', 'approved', 'rejected');

-- Create salary_status enum
CREATE TYPE public.salary_status AS ENUM ('pending', 'approved', 'rejected');

-- ============================================
-- PROFILES TABLE
-- ============================================
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT,
  status account_status NOT NULL DEFAULT 'inactive',
  balance NUMERIC(12,2) NOT NULL DEFAULT 0,
  pro_unlocked BOOLEAN NOT NULL DEFAULT false,
  referral_code TEXT UNIQUE NOT NULL DEFAULT substr(md5(random()::text), 1, 8),
  referred_by UUID REFERENCES public.profiles(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- ============================================
-- USER ROLES TABLE
-- ============================================
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role app_role NOT NULL,
  UNIQUE(user_id, role)
);

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- ============================================
-- ADMIN SETTINGS TABLE
-- ============================================
CREATE TABLE public.admin_settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.admin_settings ENABLE ROW LEVEL SECURITY;

-- Insert default settings
INSERT INTO public.admin_settings (key, value) VALUES
  ('bkash_number', '01XXXXXXXXX'),
  ('nagad_number', '01XXXXXXXXX'),
  ('activation_fee', '30'),
  ('pro_unlock_fee', '100'),
  ('basic_task_reward', '5'),
  ('pro_task_reward', '15'),
  ('gmail_reward', '10'),
  ('referral_commission', '20'),
  ('salary_amount', '500'),
  ('salary_direct_referrals', '10'),
  ('salary_team_referrals', '30'),
  ('min_withdrawal', '50'),
  ('gmail_password', 'DefaultPassword123');

-- ============================================
-- PAYMENTS TABLE
-- ============================================
CREATE TABLE public.payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  payment_type payment_type NOT NULL,
  method payment_method NOT NULL,
  amount NUMERIC(12,2) NOT NULL,
  transaction_id TEXT NOT NULL,
  payment_number TEXT NOT NULL,
  status payment_status NOT NULL DEFAULT 'pending',
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;

-- ============================================
-- BASIC TASKS TABLE
-- ============================================
CREATE TABLE public.basic_tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT,
  reward_amount NUMERIC(12,2) NOT NULL DEFAULT 5,
  is_pro BOOLEAN NOT NULL DEFAULT false,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.basic_tasks ENABLE ROW LEVEL SECURITY;

-- ============================================
-- TASK COMPLETIONS TABLE
-- ============================================
CREATE TABLE public.task_completions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  task_id UUID NOT NULL REFERENCES public.basic_tasks(id) ON DELETE CASCADE,
  completed_at DATE NOT NULL DEFAULT CURRENT_DATE,
  reward_amount NUMERIC(12,2) NOT NULL,
  UNIQUE(user_id, task_id, completed_at)
);

ALTER TABLE public.task_completions ENABLE ROW LEVEL SECURITY;

-- ============================================
-- GMAIL SUBMISSIONS TABLE
-- ============================================
CREATE TABLE public.gmail_submissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  gmail_address TEXT NOT NULL,
  gmail_password TEXT NOT NULL,
  status gmail_status NOT NULL DEFAULT 'pending',
  reward_amount NUMERIC(12,2),
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.gmail_submissions ENABLE ROW LEVEL SECURITY;

-- ============================================
-- WITHDRAWALS TABLE
-- ============================================
CREATE TABLE public.withdrawals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  amount NUMERIC(12,2) NOT NULL,
  method payment_method NOT NULL,
  account_number TEXT NOT NULL,
  status withdrawal_status NOT NULL DEFAULT 'pending',
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.withdrawals ENABLE ROW LEVEL SECURITY;

-- ============================================
-- SALARY CLAIMS TABLE
-- ============================================
CREATE TABLE public.salary_claims (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  month INTEGER NOT NULL,
  year INTEGER NOT NULL,
  amount NUMERIC(12,2) NOT NULL,
  status salary_status NOT NULL DEFAULT 'pending',
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, month, year)
);

ALTER TABLE public.salary_claims ENABLE ROW LEVEL SECURITY;

-- ============================================
-- SECURITY DEFINER FUNCTIONS
-- ============================================
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

CREATE OR REPLACE FUNCTION public.is_admin(_user_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT public.has_role(_user_id, 'admin')
$$;

-- ============================================
-- TRIGGER: Auto-create profile on signup
-- ============================================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _referral_code TEXT;
BEGIN
  _referral_code := substr(md5(NEW.id::text || random()::text), 1, 8);
  INSERT INTO public.profiles (id, email, full_name, referral_code)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
    _referral_code
  );
  -- Assign default user role
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'user');
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============================================
-- TRIGGER: Update updated_at
-- ============================================
CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_settings_updated_at
  BEFORE UPDATE ON public.admin_settings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

-- ============================================
-- RLS POLICIES: profiles
-- ============================================
CREATE POLICY "Users can view own profile"
  ON public.profiles FOR SELECT TO authenticated
  USING (id = auth.uid() OR public.is_admin(auth.uid()));

CREATE POLICY "Users can update own profile"
  ON public.profiles FOR UPDATE TO authenticated
  USING (id = auth.uid() OR public.is_admin(auth.uid()));

-- ============================================
-- RLS POLICIES: user_roles
-- ============================================
CREATE POLICY "Admins can manage roles"
  ON public.user_roles FOR ALL TO authenticated
  USING (public.is_admin(auth.uid()));

CREATE POLICY "Users can read own role"
  ON public.user_roles FOR SELECT TO authenticated
  USING (user_id = auth.uid());

-- ============================================
-- RLS POLICIES: admin_settings
-- ============================================
CREATE POLICY "Anyone authenticated can read settings"
  ON public.admin_settings FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Admins can update settings"
  ON public.admin_settings FOR UPDATE TO authenticated
  USING (public.is_admin(auth.uid()));

CREATE POLICY "Admins can insert settings"
  ON public.admin_settings FOR INSERT TO authenticated
  WITH CHECK (public.is_admin(auth.uid()));

-- ============================================
-- RLS POLICIES: payments
-- ============================================
CREATE POLICY "Users can view own payments"
  ON public.payments FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_admin(auth.uid()));

CREATE POLICY "Users can create payments"
  ON public.payments FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Admins can update payments"
  ON public.payments FOR UPDATE TO authenticated
  USING (public.is_admin(auth.uid()));

-- ============================================
-- RLS POLICIES: basic_tasks
-- ============================================
CREATE POLICY "Active users can view tasks"
  ON public.basic_tasks FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Admins can manage tasks"
  ON public.basic_tasks FOR ALL TO authenticated
  USING (public.is_admin(auth.uid()));

-- ============================================
-- RLS POLICIES: task_completions
-- ============================================
CREATE POLICY "Users can view own completions"
  ON public.task_completions FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_admin(auth.uid()));

CREATE POLICY "Users can create completions"
  ON public.task_completions FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());

-- ============================================
-- RLS POLICIES: gmail_submissions
-- ============================================
CREATE POLICY "Users can view own gmail submissions"
  ON public.gmail_submissions FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_admin(auth.uid()));

CREATE POLICY "Users can create gmail submissions"
  ON public.gmail_submissions FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Admins can update gmail submissions"
  ON public.gmail_submissions FOR UPDATE TO authenticated
  USING (public.is_admin(auth.uid()));

-- ============================================
-- RLS POLICIES: withdrawals
-- ============================================
CREATE POLICY "Users can view own withdrawals"
  ON public.withdrawals FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_admin(auth.uid()));

CREATE POLICY "Users can create withdrawals"
  ON public.withdrawals FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Admins can update withdrawals"
  ON public.withdrawals FOR UPDATE TO authenticated
  USING (public.is_admin(auth.uid()));

-- ============================================
-- RLS POLICIES: salary_claims
-- ============================================
CREATE POLICY "Users can view own salary claims"
  ON public.salary_claims FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_admin(auth.uid()));

CREATE POLICY "Users can create salary claims"
  ON public.salary_claims FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Admins can update salary claims"
  ON public.salary_claims FOR UPDATE TO authenticated
  USING (public.is_admin(auth.uid()));
