-- Drop existing FK to auth.users and add FK to profiles for PostgREST joins
ALTER TABLE public.payments DROP CONSTRAINT payments_user_id_fkey;
ALTER TABLE public.payments ADD CONSTRAINT payments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id);

ALTER TABLE public.withdrawals DROP CONSTRAINT withdrawals_user_id_fkey;
ALTER TABLE public.withdrawals ADD CONSTRAINT withdrawals_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id);

ALTER TABLE public.task_completions DROP CONSTRAINT task_completions_user_id_fkey;
ALTER TABLE public.task_completions ADD CONSTRAINT task_completions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id);

ALTER TABLE public.gmail_submissions DROP CONSTRAINT gmail_submissions_user_id_fkey;
ALTER TABLE public.gmail_submissions ADD CONSTRAINT gmail_submissions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id);

ALTER TABLE public.salary_claims DROP CONSTRAINT salary_claims_user_id_fkey;
ALTER TABLE public.salary_claims ADD CONSTRAINT salary_claims_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id);