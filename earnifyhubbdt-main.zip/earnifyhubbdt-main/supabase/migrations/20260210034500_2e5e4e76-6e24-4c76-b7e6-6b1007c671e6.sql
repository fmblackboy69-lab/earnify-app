
-- Fix payments SELECT policy: drop restrictive, create permissive
DROP POLICY IF EXISTS "Users can view own payments" ON public.payments;
CREATE POLICY "Users can view own payments"
  ON public.payments FOR SELECT
  USING ((user_id = auth.uid()) OR is_admin(auth.uid()));

-- Fix payments INSERT policy
DROP POLICY IF EXISTS "Users can create payments" ON public.payments;
CREATE POLICY "Users can create payments"
  ON public.payments FOR INSERT
  WITH CHECK (user_id = auth.uid());

-- Fix payments UPDATE policy
DROP POLICY IF EXISTS "Admins can update payments" ON public.payments;
CREATE POLICY "Admins can update payments"
  ON public.payments FOR UPDATE
  USING (is_admin(auth.uid()));

-- Fix task_completions SELECT policy
DROP POLICY IF EXISTS "Users can view own completions" ON public.task_completions;
CREATE POLICY "Users can view own completions"
  ON public.task_completions FOR SELECT
  USING ((user_id = auth.uid()) OR is_admin(auth.uid()));

-- Fix task_completions INSERT policy
DROP POLICY IF EXISTS "Users can create completions" ON public.task_completions;
CREATE POLICY "Users can create completions"
  ON public.task_completions FOR INSERT
  WITH CHECK (user_id = auth.uid());

-- Fix task_completions UPDATE policy
DROP POLICY IF EXISTS "Users can update own completions" ON public.task_completions;
CREATE POLICY "Users can update own completions"
  ON public.task_completions FOR UPDATE
  USING ((auth.uid() = user_id) OR is_admin(auth.uid()));

-- Fix profiles SELECT policy
DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;
CREATE POLICY "Users can view own profile"
  ON public.profiles FOR SELECT
  USING ((id = auth.uid()) OR is_admin(auth.uid()));

-- Fix profiles UPDATE policy
DROP POLICY IF EXISTS "Users can update own non-sensitive fields" ON public.profiles;
CREATE POLICY "Users can update own non-sensitive fields"
  ON public.profiles FOR UPDATE
  USING ((id = auth.uid()) OR is_admin(auth.uid()))
  WITH CHECK (
    is_admin(auth.uid()) OR (
      (id = auth.uid()) AND
      (balance = (SELECT p.balance FROM profiles p WHERE p.id = auth.uid())) AND
      (status = (SELECT p.status FROM profiles p WHERE p.id = auth.uid())) AND
      (pro_unlocked = (SELECT p.pro_unlocked FROM profiles p WHERE p.id = auth.uid()))
    )
  );

-- Fix withdrawals SELECT policy
DROP POLICY IF EXISTS "Users can view own withdrawals" ON public.withdrawals;
CREATE POLICY "Users can view own withdrawals"
  ON public.withdrawals FOR SELECT
  USING ((user_id = auth.uid()) OR is_admin(auth.uid()));

-- Fix withdrawals INSERT policy
DROP POLICY IF EXISTS "Users can create withdrawals" ON public.withdrawals;
CREATE POLICY "Users can create withdrawals"
  ON public.withdrawals FOR INSERT
  WITH CHECK (user_id = auth.uid());

-- Fix withdrawals UPDATE policy
DROP POLICY IF EXISTS "Admins can update withdrawals" ON public.withdrawals;
CREATE POLICY "Admins can update withdrawals"
  ON public.withdrawals FOR UPDATE
  USING (is_admin(auth.uid()));

-- Fix gmail_submissions policies
DROP POLICY IF EXISTS "Users can view own gmail submissions (no password)" ON public.gmail_submissions;
CREATE POLICY "Users can view own gmail submissions (no password)"
  ON public.gmail_submissions FOR SELECT
  USING ((user_id = auth.uid()) OR is_admin(auth.uid()));

DROP POLICY IF EXISTS "Users can create gmail submissions" ON public.gmail_submissions;
CREATE POLICY "Users can create gmail submissions"
  ON public.gmail_submissions FOR INSERT
  WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "Admins can update gmail submissions" ON public.gmail_submissions;
CREATE POLICY "Admins can update gmail submissions"
  ON public.gmail_submissions FOR UPDATE
  USING (is_admin(auth.uid()));

-- Fix salary_claims policies
DROP POLICY IF EXISTS "Users can view own salary claims" ON public.salary_claims;
CREATE POLICY "Users can view own salary claims"
  ON public.salary_claims FOR SELECT
  USING ((user_id = auth.uid()) OR is_admin(auth.uid()));

DROP POLICY IF EXISTS "Users can create salary claims" ON public.salary_claims;
CREATE POLICY "Users can create salary claims"
  ON public.salary_claims FOR INSERT
  WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "Admins can update salary claims" ON public.salary_claims;
CREATE POLICY "Admins can update salary claims"
  ON public.salary_claims FOR UPDATE
  USING (is_admin(auth.uid()));

-- Fix admin_settings policies
DROP POLICY IF EXISTS "Anyone authenticated can read settings" ON public.admin_settings;
CREATE POLICY "Anyone authenticated can read settings"
  ON public.admin_settings FOR SELECT
  USING (true);

DROP POLICY IF EXISTS "Admins can insert settings" ON public.admin_settings;
CREATE POLICY "Admins can insert settings"
  ON public.admin_settings FOR INSERT
  WITH CHECK (is_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins can update settings" ON public.admin_settings;
CREATE POLICY "Admins can update settings"
  ON public.admin_settings FOR UPDATE
  USING (is_admin(auth.uid()));

-- Fix basic_tasks policies
DROP POLICY IF EXISTS "Active users can view tasks" ON public.basic_tasks;
CREATE POLICY "Active users can view tasks"
  ON public.basic_tasks FOR SELECT
  USING (true);

DROP POLICY IF EXISTS "Admins can manage tasks" ON public.basic_tasks;
CREATE POLICY "Admins can manage tasks"
  ON public.basic_tasks FOR ALL
  USING (is_admin(auth.uid()));

-- Fix user_roles policies
DROP POLICY IF EXISTS "Users can read own role" ON public.user_roles;
CREATE POLICY "Users can read own role"
  ON public.user_roles FOR SELECT
  USING (user_id = auth.uid());

DROP POLICY IF EXISTS "Admins can manage roles" ON public.user_roles;
CREATE POLICY "Admins can manage roles"
  ON public.user_roles FOR ALL
  USING (is_admin(auth.uid()));
