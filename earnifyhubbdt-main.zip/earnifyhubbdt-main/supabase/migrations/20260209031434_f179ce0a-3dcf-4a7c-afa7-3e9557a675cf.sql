
-- 1. Prevent negative balances
ALTER TABLE profiles ADD CONSTRAINT positive_balance CHECK (balance >= 0);

-- 2. Restrict profiles UPDATE policy so users cannot modify balance/status/pro_unlocked directly
DROP POLICY "Users can update own profile" ON public.profiles;

CREATE POLICY "Users can update own non-sensitive fields"
  ON public.profiles FOR UPDATE TO authenticated
  USING (id = auth.uid() OR public.is_admin(auth.uid()))
  WITH CHECK (
    -- Admins can update anything
    public.is_admin(auth.uid())
    OR (
      -- Regular users: balance, status, pro_unlocked must remain unchanged
      id = auth.uid()
      AND balance = (SELECT balance FROM profiles WHERE id = auth.uid())
      AND status = (SELECT status FROM profiles WHERE id = auth.uid())
      AND pro_unlocked = (SELECT pro_unlocked FROM profiles WHERE id = auth.uid())
    )
  );

-- 3. Restrict gmail_submissions SELECT so users cannot see passwords after submission
DROP POLICY "Users can view own gmail submissions" ON public.gmail_submissions;

CREATE POLICY "Users can view own gmail submissions (no password)"
  ON public.gmail_submissions FOR SELECT TO authenticated
  USING (
    (user_id = auth.uid() AND status != 'pending')
    OR public.is_admin(auth.uid())
    OR (user_id = auth.uid())
  );

-- 4. Server-side function for task completion (atomic, with validation)
CREATE OR REPLACE FUNCTION public.complete_task(p_task_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_id UUID;
  v_reward NUMERIC;
  v_is_pro BOOLEAN;
  v_profile RECORD;
BEGIN
  v_user_id := auth.uid();
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  -- Get user profile
  SELECT status, pro_unlocked INTO v_profile
  FROM profiles WHERE id = v_user_id;

  IF v_profile.status != 'active' THEN
    RAISE EXCEPTION 'Account not active';
  END IF;

  -- Get task info
  SELECT reward_amount, is_pro INTO v_reward, v_is_pro
  FROM basic_tasks WHERE id = p_task_id AND is_active = true;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Task not found or inactive';
  END IF;

  IF v_is_pro AND NOT v_profile.pro_unlocked THEN
    RAISE EXCEPTION 'Pro access required';
  END IF;

  -- Insert completion (unique constraint prevents duplicates)
  INSERT INTO task_completions (user_id, task_id, reward_amount)
  VALUES (v_user_id, p_task_id, v_reward);

  -- Atomic balance update
  UPDATE profiles SET balance = balance + v_reward WHERE id = v_user_id;

  RETURN jsonb_build_object('success', true, 'reward', v_reward);
EXCEPTION
  WHEN unique_violation THEN
    RETURN jsonb_build_object('error', 'Task already completed today');
END;
$$;

GRANT EXECUTE ON FUNCTION public.complete_task TO authenticated;

-- 5. Server-side function for approving payments (activation/pro_unlock)
CREATE OR REPLACE FUNCTION public.approve_payment(p_payment_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_payment RECORD;
  v_commission NUMERIC;
  v_referrer_id UUID;
BEGIN
  IF NOT public.is_admin(auth.uid()) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;

  SELECT * INTO v_payment FROM payments WHERE id = p_payment_id AND status = 'pending';
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Payment not found or already processed';
  END IF;

  UPDATE payments SET status = 'approved', reviewed_at = now() WHERE id = p_payment_id;

  IF v_payment.payment_type = 'activation' THEN
    UPDATE profiles SET status = 'active' WHERE id = v_payment.user_id;

    -- Referral commission
    SELECT referred_by INTO v_referrer_id FROM profiles WHERE id = v_payment.user_id;
    IF v_referrer_id IS NOT NULL THEN
      SELECT COALESCE((SELECT value::numeric FROM admin_settings WHERE key = 'referral_commission'), 20) INTO v_commission;
      UPDATE profiles SET balance = balance + v_commission WHERE id = v_referrer_id;
    END IF;
  ELSIF v_payment.payment_type = 'pro_unlock' THEN
    UPDATE profiles SET pro_unlocked = true WHERE id = v_payment.user_id;
  END IF;

  RETURN jsonb_build_object('success', true);
END;
$$;

GRANT EXECUTE ON FUNCTION public.approve_payment TO authenticated;

-- 6. Server-side function for rejecting payments
CREATE OR REPLACE FUNCTION public.reject_payment(p_payment_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_admin(auth.uid()) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;

  UPDATE payments SET status = 'rejected', reviewed_at = now() WHERE id = p_payment_id AND status = 'pending';
  RETURN jsonb_build_object('success', true);
END;
$$;

GRANT EXECUTE ON FUNCTION public.reject_payment TO authenticated;

-- 7. Server-side function for approving gmail submissions
CREATE OR REPLACE FUNCTION public.approve_gmail(p_submission_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_submission RECORD;
  v_reward NUMERIC;
BEGIN
  IF NOT public.is_admin(auth.uid()) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;

  SELECT * INTO v_submission FROM gmail_submissions WHERE id = p_submission_id AND status = 'pending';
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Submission not found or already processed';
  END IF;

  SELECT COALESCE((SELECT value::numeric FROM admin_settings WHERE key = 'gmail_reward'), 10) INTO v_reward;

  UPDATE gmail_submissions SET status = 'approved', reward_amount = v_reward, reviewed_at = now() WHERE id = p_submission_id;
  UPDATE profiles SET balance = balance + v_reward WHERE id = v_submission.user_id;

  RETURN jsonb_build_object('success', true, 'reward', v_reward);
END;
$$;

GRANT EXECUTE ON FUNCTION public.approve_gmail TO authenticated;

-- 8. Server-side function for rejecting gmail submissions
CREATE OR REPLACE FUNCTION public.reject_gmail(p_submission_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_admin(auth.uid()) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;

  UPDATE gmail_submissions SET status = 'rejected', reviewed_at = now() WHERE id = p_submission_id AND status = 'pending';
  RETURN jsonb_build_object('success', true);
END;
$$;

GRANT EXECUTE ON FUNCTION public.reject_gmail TO authenticated;

-- 9. Server-side function for approving salary claims
CREATE OR REPLACE FUNCTION public.approve_salary(p_claim_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_claim RECORD;
BEGIN
  IF NOT public.is_admin(auth.uid()) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;

  SELECT * INTO v_claim FROM salary_claims WHERE id = p_claim_id AND status = 'pending';
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Claim not found or already processed';
  END IF;

  UPDATE salary_claims SET status = 'approved', reviewed_at = now() WHERE id = p_claim_id;
  UPDATE profiles SET balance = balance + v_claim.amount WHERE id = v_claim.user_id;

  RETURN jsonb_build_object('success', true);
END;
$$;

GRANT EXECUTE ON FUNCTION public.approve_salary TO authenticated;

-- 10. Server-side function for rejecting salary claims
CREATE OR REPLACE FUNCTION public.reject_salary(p_claim_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_admin(auth.uid()) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;

  UPDATE salary_claims SET status = 'rejected', reviewed_at = now() WHERE id = p_claim_id AND status = 'pending';
  RETURN jsonb_build_object('success', true);
END;
$$;

GRANT EXECUTE ON FUNCTION public.reject_salary TO authenticated;

-- 11. Server-side function for processing withdrawals
CREATE OR REPLACE FUNCTION public.approve_withdrawal(p_withdrawal_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_withdrawal RECORD;
  v_balance NUMERIC;
BEGIN
  IF NOT public.is_admin(auth.uid()) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;

  SELECT * INTO v_withdrawal FROM withdrawals WHERE id = p_withdrawal_id AND status IN ('pending', 'processing');
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Withdrawal not found or already processed';
  END IF;

  SELECT balance INTO v_balance FROM profiles WHERE id = v_withdrawal.user_id FOR UPDATE;
  IF v_balance < v_withdrawal.amount THEN
    RAISE EXCEPTION 'Insufficient balance';
  END IF;

  UPDATE withdrawals SET status = 'completed', reviewed_at = now() WHERE id = p_withdrawal_id;
  UPDATE profiles SET balance = balance - v_withdrawal.amount WHERE id = v_withdrawal.user_id;

  RETURN jsonb_build_object('success', true);
END;
$$;

GRANT EXECUTE ON FUNCTION public.approve_withdrawal TO authenticated;

-- 12. Server-side function for rejecting withdrawals
CREATE OR REPLACE FUNCTION public.reject_withdrawal(p_withdrawal_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_admin(auth.uid()) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;

  UPDATE withdrawals SET status = 'rejected', reviewed_at = now() WHERE id = p_withdrawal_id AND status IN ('pending', 'processing');
  RETURN jsonb_build_object('success', true);
END;
$$;

GRANT EXECUTE ON FUNCTION public.reject_withdrawal TO authenticated;
