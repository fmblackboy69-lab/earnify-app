
-- Add link column to basic_tasks
ALTER TABLE public.basic_tasks ADD COLUMN link TEXT;

-- Add status and proof columns to task_completions
ALTER TABLE public.task_completions 
  ADD COLUMN status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  ADD COLUMN proof_url TEXT;

-- Remove the unique constraint on (user_id, task_id, completed_at) if exists, we need new logic
-- Drop old complete_task function and recreate
CREATE OR REPLACE FUNCTION public.complete_task(p_task_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_user_id UUID;
  v_reward NUMERIC;
  v_is_pro BOOLEAN;
  v_profile RECORD;
BEGIN
  v_user_id := auth.uid();
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  SELECT status, pro_unlocked INTO v_profile
  FROM profiles WHERE id = v_user_id;

  IF v_profile.status != 'active' THEN
    RAISE EXCEPTION 'Account not active';
  END IF;

  SELECT reward_amount, is_pro INTO v_reward, v_is_pro
  FROM basic_tasks WHERE id = p_task_id AND is_active = true;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Task not found or inactive';
  END IF;

  IF v_is_pro AND NOT v_profile.pro_unlocked THEN
    RAISE EXCEPTION 'Pro access required';
  END IF;

  -- Insert completion as pending (no balance update yet)
  INSERT INTO task_completions (user_id, task_id, reward_amount, status)
  VALUES (v_user_id, p_task_id, v_reward, 'pending');

  RETURN jsonb_build_object('success', true, 'reward', v_reward);
EXCEPTION
  WHEN unique_violation THEN
    RETURN jsonb_build_object('error', 'Task already completed today');
END;
$function$;

-- Create approve/reject functions for task completions
CREATE OR REPLACE FUNCTION public.approve_task_completion(p_completion_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_completion RECORD;
BEGIN
  IF NOT public.is_admin(auth.uid()) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;

  SELECT * INTO v_completion FROM task_completions WHERE id = p_completion_id AND status = 'pending';
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Completion not found or already processed';
  END IF;

  UPDATE task_completions SET status = 'approved' WHERE id = p_completion_id;
  UPDATE profiles SET balance = balance + v_completion.reward_amount WHERE id = v_completion.user_id;

  RETURN jsonb_build_object('success', true);
END;
$function$;

CREATE OR REPLACE FUNCTION public.reject_task_completion(p_completion_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  IF NOT public.is_admin(auth.uid()) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;

  UPDATE task_completions SET status = 'rejected' WHERE id = p_completion_id AND status = 'pending';
  RETURN jsonb_build_object('success', true);
END;
$function$;

-- Create storage bucket for task proofs
INSERT INTO storage.buckets (id, name, public) VALUES ('task-proofs', 'task-proofs', true);

-- Storage policies
CREATE POLICY "Users can upload their own proofs"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'task-proofs' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Anyone can view proofs"
ON storage.objects FOR SELECT
USING (bucket_id = 'task-proofs');

-- RLS policy: users can update their own completions (for adding proof_url)
CREATE POLICY "Users can update own completions"
ON public.task_completions FOR UPDATE
USING (auth.uid() = user_id);
